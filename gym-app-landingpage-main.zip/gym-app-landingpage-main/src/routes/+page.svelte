<script>
    import Conversion from "../components/Conversion.svelte";
    import FaQs from "../components/FAQs.svelte";
    import Hero from "../components/Hero.svelte";
    import Product from "../components/Product.svelte";
    import Reviews from "../components/Reviews.svelte";
</script>

<main class="flex flex-col">
    <Hero />
    <Product />
    <Reviews />
    <FaQs />
    <Conversion />
</main>
